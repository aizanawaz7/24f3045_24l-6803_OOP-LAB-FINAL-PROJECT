#ifndef STRONGHOLD_H
#define STRONGHOLD_H
#include <string>
using namespace std;

class Resource; // Forward declaration

class SocialClass {
protected:
    string className;
    int population;
    float happiness;
    float taxRate;
    float influence;

public:
    SocialClass(string name, int pop, float happy, float infl) :
        className(name), population(pop), happiness(happy), taxRate(0.1f), influence(infl) {}
        
    virtual ~SocialClass() = default;
    
    // Implement all methods inline
    int getPopulation() const { return population; }
    float getTaxRate() const { return taxRate; }
    float getHappiness() const { return happiness; }
    float getInfluence() const { return influence; }
    
    void updateHappiness(float change) {
        happiness += change;
        happiness = happiness > 1.0f ? 1.0f : (happiness < 0.0f ? 0.0f : happiness);
    }
    
    void changePopulation(int change) {
        population += change;
        population = population < 0 ? 0 : population;
    }
    
    virtual void calculateTax() = 0;
    virtual void yearlyUpdate() = 0;
};

class Leader {
protected:
    string name;
    float leadership;
    float corruptionLevel;

public:
    Leader(string n, float ldr) : name(n), leadership(ldr), corruptionLevel(0.1f) {}
    virtual ~Leader() = default;
    
    // Implement all methods inline
    string getName() const { return name; }
    float getLeadership() const { return leadership; }
    float getCorruption() const { return corruptionLevel; }
    
    void adjustCorruption(float amount) {
        corruptionLevel += amount;
        corruptionLevel = corruptionLevel > 1.0f ? 1.0f : 
                         (corruptionLevel < 0.0f ? 0.0f : corruptionLevel);
    }
    
    virtual void makeDecisions() = 0;
};

#endif