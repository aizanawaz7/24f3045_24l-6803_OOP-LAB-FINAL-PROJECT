#ifndef EVENT_H
#define EVENT_H

#include <string>
using namespace std;

// First define the base Event class
class Event {
protected:
    string name;
    bool active = false;
public:
    Event(const string& eventName) : name(eventName) {}
    virtual ~Event() = default;
    
    virtual void trigger() { active = true; }
    virtual void resolve() { active = false; }
    bool checkActive() const { return active; }
    virtual void applyEffects() = 0;  // Pure virtual
    
    string getName() const { return name; }
};

// Then define derived classes
class Famine : public Event {
public:
    Famine();
    void trigger() override;
    void applyEffects() override;
};

class War : public Event {
public:
    War();
    void trigger() override;
    void applyEffects() override;
};

#endif