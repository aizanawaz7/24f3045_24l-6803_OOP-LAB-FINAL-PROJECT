#include <iostream>
#include <ctime>
#include <cstdlib>
#include "Resource.h"
#include "Treasury.h"
#include "Population.h"
#include "Army.h"
#include "Leadership.h"
#include "EventSystem.h"
#include "Economy.h"
using namespace std;

// Remove clearScreen() completely
void waitForEnter() {
    cout << "Press Enter to continue to next year...";
    cin.ignore(); // Clear any existing input
    cin.get();    // Wait for Enter key
}


void displayKingdomStatus(int year, 
                        const Peasant& peasants,
                        const Noble& nobles,
                        const Army& army,
                        const Market& market,
                        const Treasury& treasury,
                        const Leader* leader,
                        const Event* currentEvent) {
    cout << "\n========================================\n";
    cout << " YEAR " << year << " - KINGDOM STATUS\n";
    cout << "========================================\n";
    
    cout << "\n[LEADERSHIP]\n";
    cout << " Ruler: " << leader->getName() 
         << " | Leadership: " << leader->getLeadership() * 100 << "%"
         << " | Corruption: " << leader->getCorruption() * 100 << "%\n";
    
    cout << "\n[POPULATION]\n";
    cout << " Peasants: " << peasants.getPopulation() 
         << " | Happiness: " << peasants.getHappiness() * 100 << "%\n";
    cout << " Nobles: " << nobles.getPopulation() 
         << " | Happiness: " << nobles.getHappiness() * 100 << "%\n";
    
    cout << "\n[MILITARY]\n";
    cout << " Soldiers: " << army.getSoldierCount()
         << " | Morale: " << army.getMorale() * 100 << "%\n";
    
    cout << "\n[ECONOMY]\n";
    cout << " Treasury: " << treasury.getGold() << " gold\n";
    
    cout << "\n[RESOURCES]\n";
    market.displayResources();
    
    if (currentEvent && currentEvent->checkActive()) {
        cout << "\n!! ACTIVE EVENT: " << currentEvent->getName() << " !!\n";
    }
    cout << "========================================\n";
}

int main() {
    srand(time(0));

    // Removed clearScreen() at start
    
    // Initialize game state
    Market market;
    Treasury treasury(5000);
    Peasant peasants(100);
    Noble nobles(10);
    Army army(20);
    Council council;
    Bank bank(&treasury);
    Famine famine;
    Plague plague;
    War war;
    Election election;
    Event* currentEvent = nullptr;
    int eventCooldown = 0;

    // 10-year game loop
    for (int year = 1; year <= 10; year++) {
        displayKingdomStatus(year, peasants, nobles, army, market, 
                           treasury, council.getCurrentLeader(), currentEvent);

        // Yearly updates
        Resource* food = market.getFood();
        if (peasants.getHappiness() > 0.6f && food->getQuantity() > peasants.getPopulation() * 2) {
            int newPeasants = static_cast<int>(peasants.getPopulation() * 0.05f);
            peasants.changePopulation(newPeasants);
            cout << newPeasants << " peasants born this year.\n";
        }
        if (peasants.getHappiness() < 0.3f && rand() % 100 < 30) {
            int rebels = peasants.getPopulation() / 5;
            peasants.changePopulation(-rebels);
            cout << rebels << " peasants revolted!\n";
        }
        
        float foodPerPerson = static_cast<float>(food->getQuantity()) / peasants.getPopulation();
        if (foodPerPerson < 1.0f) peasants.updateHappiness(-0.2f);
        else if (foodPerPerson > 2.0f) peasants.updateHappiness(0.1f);

        if (treasury.getGold() < 1000) {
            nobles.updateHappiness(-0.15f);
        } else {
            nobles.updateHappiness(0.05f);
        }

        army.yearlyUpdate(treasury);
        market.updateMarket();
        treasury.collectTax(peasants);
        treasury.collectTax(nobles);
        treasury.applyInflation();
        bank.processLoans();
        bank.investigateFraud();
        council.getCurrentLeader()->makeDecisions();

        // Event handling
        if (eventCooldown <= 0 && rand() % 100 < 25) {
            int eventType = rand() % 4;
            switch (eventType) {
                case 0: currentEvent = &famine; break;
                case 1: currentEvent = &plague; break;
                case 2: currentEvent = &war; break;
                case 3: 
                    currentEvent = &election; 
                    council.holdElection();
                    break;
            }
            if (currentEvent) {
                currentEvent->trigger();
                eventCooldown = 2 + rand() % 3;
                cout << "\nEVENT: " << currentEvent->getName() << " started!\n";
            }
        }

        if (currentEvent && currentEvent->checkActive()) {
            currentEvent->applyEffects();
            if (currentEvent->getName() == "Plague") {
                peasants.applyPlague();
            } else if (currentEvent->getName() == "War") {
                army.updateMorale(-0.2f);
            } else if (currentEvent->getName() == "Famine") {
                market.getFood()->consume(market.getFood()->getQuantity() / 2);
            }
            if (--eventCooldown <= 0) {
                currentEvent->resolve();
                cout << "EVENT: " << currentEvent->getName() << " ended.\n";
                currentEvent = nullptr;
            }
        }

        waitForEnter();
    }

    cout << "\n=== 10 YEAR REIGN COMPLETE ===\n";
    return 0;
}
//TO RUN THE CODE PASTE THIS ON TERMINAL AND FOR MOVING THE NEXT YEAR PRESS ENTER ONE TIME OR TWICE AFTER COMPILING OR EXECUTING THESE TWO COMMANDS FIRST ONE THEN SECOND 
//    g++ -std=c++11 -I. main.cpp EventSystem.cpp Resource.cpp Treasury.cpp Population.cpp Army.cpp Leadership.cpp Economy.cpp -o StrongholdGame.exe
//   .\StrongholdGame.exe