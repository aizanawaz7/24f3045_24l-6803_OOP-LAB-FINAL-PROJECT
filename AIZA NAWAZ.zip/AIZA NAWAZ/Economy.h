#ifndef ECONOMY_H
#define ECONOMY_H
#include "Treasury.h"

class Bank {
    Treasury* treasury;
    float fraudRisk;
public:
    Bank(Treasury* t);
    void processLoans();
    void investigateFraud();
};

#endif