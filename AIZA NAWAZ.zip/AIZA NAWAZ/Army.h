#ifndef ARMY_H
#define ARMY_H
#include "Population.h"
#include "Treasury.h"

class Army {
    Soldier* soldiers;
    int soldierCount;
    float morale;
    bool isCorrupt;
public:
    Army(int count);
    ~Army();
    void yearlyUpdate(Treasury& treasury);
    int getSoldierCount() const { return soldierCount; }
    int getTotalStrength() const;
    float getMorale() const { return morale; }
    bool checkCorruption() const { return isCorrupt; }
    void updateMorale(float change);
};

#endif