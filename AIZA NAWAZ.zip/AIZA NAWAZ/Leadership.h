#ifndef LEADERSHIP_H
#define LEADERSHIP_H
#include "Stronghold.h"

class King : public Leader {
public:
    King(string name);
    void makeDecisions() override;
};

class Council {
    Leader* members[3];
    Leader* currentLeader;
public:
    Council();
    ~Council();
    void holdElection();
    Leader* getCurrentLeader() const;
};
#endif