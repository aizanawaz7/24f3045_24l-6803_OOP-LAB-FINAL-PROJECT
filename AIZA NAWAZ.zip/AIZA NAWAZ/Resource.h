#ifndef RESOURCE_H
#define RESOURCE_H
#include <string>
using namespace std;

class Resource {
protected:
    string resourceName;
    int quantity;
public:
    Resource(string name, int qty);
    virtual ~Resource() = default;
    virtual void yearlyUpdate() = 0;

    void consume(int amount);
    void add(int amount);
    int getQuantity() const;
    string getName() const;
};

class Food : public Resource {
public:
    Food(int qty);
    void yearlyUpdate() override;
};

class Wood : public Resource {
public:
    Wood(int qty);
    void yearlyUpdate() override;
};

class Stone : public Resource {
public:
    Stone(int qty);
    void yearlyUpdate() override;
};

class Iron : public Resource {
public:
    Iron(int qty);
    void yearlyUpdate() override;
};

class Market {
    Food* food;
    Wood* wood;
    Stone* stone;
    Iron* iron;
public:
    Market();
    ~Market();
    void updateMarket();
    void displayResources() const;
    Food* getFood() const { return food; }
    Wood* getWood() const { return wood; }
    Stone* getStone() const { return stone; }
    Iron* getIron() const { return iron; }
};

#endif