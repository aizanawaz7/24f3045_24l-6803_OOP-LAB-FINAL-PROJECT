#ifndef TREASURY_H
#define TREASURY_H
#include "Stronghold.h"

class Treasury {
    int gold;
    float inflationRate;
    int loanDebt;
    float interestRate;
    float corruptionLevel;
public:
    Treasury(int initialGold);
    void collectTax(SocialClass& sc);
    void applyInflation();
    void takeLoan(int amount);
    void repayLoan(int amount);
    void spendGold(int amount); // New method for spending
    void detectCorruption();
    void audit();
    int getGold() const { return gold; }
    int getDebt() const { return loanDebt; }
    float getInflation() const { return inflationRate; }
    float getCorruption() const { return corruptionLevel; }
};

#endif