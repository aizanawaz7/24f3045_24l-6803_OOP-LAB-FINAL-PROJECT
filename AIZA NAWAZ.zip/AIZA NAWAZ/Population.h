#ifndef POPULATION_H
#define POPULATION_H
#include "Stronghold.h"
#include "Treasury.h"

class Peasant : public SocialClass {
    float birthRate;
    float revoltRisk;
public:
    Peasant(int pop);
    void calculateTax() override;
    void yearlyUpdate() override; // Parameter removed, use Market in main
    void applyPlague();
};

class Noble : public SocialClass {
    float luxuryDemand;
public:
    Noble(int pop);
    void calculateTax() override;
    void yearlyUpdate() override; // Parameter removed, use Treasury in main
};

class Soldier : public Peasant {
    int strength;
    bool isDeserting;
public:
    Soldier(int count);
    void yearlyUpdate() override; // Add override
    int getStrength() const;
    bool checkDesertion() const;
    void updateMorale(float change);
};

#endif