#include "Event.h"
#include <iostream>
using namespace std;

Famine::Famine() : Event("Famine") {}
void Famine::trigger() {
    Event::trigger();
    cout << "Famine triggered!\n";
}
void Famine::applyEffects() {
    cout << "Applying famine effects...\n";
}

War::War() : Event("War") {}
void War::trigger() {
    Event::trigger();
    cout << "War triggered!\n";
}
void War::applyEffects() {
    cout << "Applying war effects...\n";
}