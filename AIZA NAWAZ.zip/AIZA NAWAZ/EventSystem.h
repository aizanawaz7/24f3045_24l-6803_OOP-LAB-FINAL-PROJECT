#ifndef EVENT_SYSTEM_H
#define EVENT_SYSTEM_H
#include <string>
#include <iostream>
using namespace std;

class Event {
protected:
    string name;
    bool active = false;
public:
    Event(const string& eventName) : name(eventName) {}
    virtual ~Event() = default;
    virtual void trigger() { active = true; }
    virtual void resolve() { active = false; }
    bool checkActive() const { return active; }
    virtual void applyEffects() = 0;
    string getName() const { return name; }
};

class Famine : public Event {
public:
    Famine();
    void trigger() override;
    void applyEffects() override;
};

class Plague : public Event {
public:
    Plague();
    void applyEffects() override;
};

class War : public Event {
public:
    War();
    void trigger() override;
    void applyEffects() override;
};

class Election : public Event {
public:
    Election();
    void applyEffects() override;
};

#endif