#include "Economy.h"
#include <iostream>
using namespace std;

Bank::Bank(Treasury* t) : treasury(t), fraudRisk(0.1f) {}

void Bank::processLoans() {
    if (rand() % 100 < fraudRisk * 100) {
        treasury->takeLoan(500);
        cout << "Bank fraud detected!\n";
    }
}

void Bank::investigateFraud() {
    fraudRisk = fraudRisk > 0.05f ? fraudRisk - 0.05f : 0.0f;
}