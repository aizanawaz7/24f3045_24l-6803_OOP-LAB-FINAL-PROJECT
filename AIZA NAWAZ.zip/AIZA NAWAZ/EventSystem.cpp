#include "EventSystem.h"

Famine::Famine() : Event("Famine") {}
void Famine::trigger() {
    Event::trigger();
    cout << "Famine triggered!\n";
}
void Famine::applyEffects() {
    cout << "Crops failed! Food production halved this year.\n";
}

Plague::Plague() : Event("Plague") {}
void Plague::applyEffects() {
    cout << "Plague spreads! Population reduced by 20%.\n";
}

War::War() : Event("War") {}
void War::trigger() {
    Event::trigger();
    cout << "War triggered!\n";
}
void War::applyEffects() {
    cout << "War declared! Army morale drops significantly.\n";
}

Election::Election() : Event("Election") {}
void Election::applyEffects() {
    cout << "New leader elected! Policies may change.\n";
}