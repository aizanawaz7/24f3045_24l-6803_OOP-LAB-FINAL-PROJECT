#include "Treasury.h"
#include <iostream>
using namespace std;

Treasury::Treasury(int initialGold) : 
    gold(initialGold), 
    inflationRate(0.02f), 
    loanDebt(0), 
    interestRate(0.1f), 
    corruptionLevel(0.0f) {}

void Treasury::collectTax(SocialClass& sc) {
    sc.calculateTax();
    int expected = sc.getPopulation() * sc.getTaxRate();
    int collected = expected * (1.0f - corruptionLevel);
    gold += collected;
    if (corruptionLevel > 0.3f) {
        cout << "Tax collectors stole " << (expected - collected) << " gold!\n";
    }
}

void Treasury::applyInflation() {
    gold -= static_cast<int>(gold * inflationRate);
    inflationRate += 0.005f;
}

void Treasury::takeLoan(int amount) {
    gold += amount;
    loanDebt += amount * (1 + interestRate);
    corruptionLevel += 0.1f;
}

void Treasury::repayLoan(int amount) {
    gold -= amount;
    loanDebt = loanDebt > amount ? loanDebt - amount : 0;
}

void Treasury::spendGold(int amount) {
    gold = gold > amount ? gold - amount : 0;
}

void Treasury::detectCorruption() {
    if (rand() % 100 < 30) {
        corruptionLevel = corruptionLevel > 0.2f ? corruptionLevel - 0.2f : 0.0f;
    }
}

void Treasury::audit() {
    gold += loanDebt * corruptionLevel;
    corruptionLevel *= 0.5f;
}