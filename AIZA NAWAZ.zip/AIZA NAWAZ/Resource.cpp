#include "Resource.h"
#include <iostream>
using namespace std;

Resource::Resource(string name, int qty) : resourceName(name), quantity(qty) {}

void Resource::consume(int amount) {
    quantity = quantity > amount ? quantity - amount : 0;
}

void Resource::add(int amount) { 
    quantity += amount; 
}

int Resource::getQuantity() const { 
    return quantity; 
}

string Resource::getName() const { 
    return resourceName; 
}

Food::Food(int qty) : Resource("Food", qty) {}
void Food::yearlyUpdate() {
    add(quantity / 5); // 20% growth
}

Wood::Wood(int qty) : Resource("Wood", qty) {}
void Wood::yearlyUpdate() {
    add(50);
}

Stone::Stone(int qty) : Resource("Stone", qty) {}
void Stone::yearlyUpdate() {
    add(30);
}

Iron::Iron(int qty) : Resource("Iron", qty) {}
void Iron::yearlyUpdate() {
    add(20);
}

Market::Market() : 
    food(new Food(1000)),
    wood(new Wood(500)),
    stone(new Stone(300)),
    iron(new Iron(200)) {}

Market::~Market() {
    delete food;
    delete wood;
    delete stone;
    delete iron;
}

void Market::updateMarket() {
    food->yearlyUpdate();
    wood->yearlyUpdate();
    stone->yearlyUpdate();
    iron->yearlyUpdate();
}

void Market::displayResources() const {
    cout << "Food: " << food->getQuantity() 
         << " | Wood: " << wood->getQuantity()
         << " | Stone: " << stone->getQuantity()
         << " | Iron: " << iron->getQuantity() << endl;
}