#include "Army.h"

Army::Army(int count) : 
    soldierCount(count), morale(0.7f), isCorrupt(false) {
    soldiers = new Soldier(count);
}

Army::~Army() { 
    delete soldiers; 
}

void Army::yearlyUpdate(Treasury& treasury) {
    int wages = soldierCount * 5;
    if (treasury.getGold() >= wages) {
        treasury.spendGold(wages);
        morale += 0.05f;
    } else {
        morale -= 0.15f;
        isCorrupt = (rand() % 100 < 30);
    }
    morale = morale > 1.0f ? 1.0f : (morale < 0.1f ? 0.1f : morale);
}

int Army::getTotalStrength() const {
    return soldiers->getStrength() * soldierCount * morale;
}

void Army::updateMorale(float change) {
    morale += change;
    morale = morale > 1.0f ? 1.0f : (morale < 0.1f ? 0.1f : morale);
}