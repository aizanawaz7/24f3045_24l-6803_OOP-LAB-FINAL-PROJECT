#include "Leadership.h"
#include<iostream>

King::King(string name) : Leader(name, 0.8f) {}
void King::makeDecisions() {
    if (getCorruption() > 0.5f) {
        cout << getName() << " made corrupt decisions!\n";
    } else {
        cout << getName() << " ruled wisely.\n";
    }
}

Council::Council() {
    members[0] = new King("Robert");
    members[1] = new King("Eddard");
    members[2] = new King("Joffrey");
    currentLeader = members[0];
}

Council::~Council() {
    for (int i = 0; i < 3; i++) delete members[i];
}

void Council::holdElection() {
    currentLeader = members[rand() % 3];
}

Leader* Council::getCurrentLeader() const {
    return currentLeader;
}