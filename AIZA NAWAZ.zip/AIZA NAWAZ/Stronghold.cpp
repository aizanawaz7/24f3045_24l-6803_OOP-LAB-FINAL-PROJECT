#include "Stronghold.h"

SocialClass::SocialClass(string name, int pop, float happy, float infl) :
    className(name), population(pop), happiness(happy), taxRate(0.1f), influence(infl) {}

int SocialClass::getPopulation() const { return population; }
float SocialClass::getTaxRate() const { return taxRate; }
float SocialClass::getHappiness() const { return happiness; }
float SocialClass::getInfluence() const { return influence; }

void SocialClass::updateHappiness(float change) {
    happiness += change;
    happiness = happiness > 1.0f ? 1.0f : (happiness < 0.0f ? 0.0f : happiness);
}

void SocialClass::changePopulation(int change) {
    population += change;
    population = population < 0 ? 0 : population;
}

Leader::Leader(string n, float ldr) : name(n), leadership(ldr), corruptionLevel(0.1f) {}

string Leader::getName() const { return name; }
float Leader::getLeadership() const { return leadership; }
float Leader::getCorruption() const { return corruptionLevel; }

void Leader::adjustCorruption(float amount) {
    corruptionLevel += amount;
    corruptionLevel = corruptionLevel > 1.0f ? 1.0f : (corruptionLevel < 0.0f ? 0.0f : corruptionLevel);
}
