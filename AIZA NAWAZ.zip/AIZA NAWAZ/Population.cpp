#include "Population.h"
#include "Resource.h"
#include <iostream>
using namespace std;

Peasant::Peasant(int pop) : 
    SocialClass("Peasant", pop, 0.5f, 0.2f), 
    birthRate(0.05f), revoltRisk(0.3f) {}

void Peasant::calculateTax() {
    if (happiness < 0.2f) taxRate = 0.4f;
    else if (happiness < 0.5f) taxRate = 0.3f;
    else taxRate = 0.2f;
}

void Peasant::yearlyUpdate() {
    // Updated in main to pass Resource* food
}

void Peasant::applyPlague() {
    int deaths = population / 4;
    changePopulation(-deaths);
    cout << "Plague killed " << deaths << " peasants.\n";
}

Noble::Noble(int pop) : 
    SocialClass("Noble", pop, 0.8f, 0.7f), 
    luxuryDemand(0.1f) {}

void Noble::calculateTax() {
    taxRate = (happiness < 0.6f) ? 0.15f : 0.1f;
}

void Noble::yearlyUpdate() {
    // Updated in main to use Treasury
}

Soldier::Soldier(int count) : 
    Peasant(count), strength(count * 10), isDeserting(false) {}

void Soldier::yearlyUpdate() {
    Peasant::yearlyUpdate();
    updateMorale(-0.05f); // Example soldier-specific logic
}

int Soldier::getStrength() const { 
    return strength; 
}

bool Soldier::checkDesertion() const {
    return isDeserting;
}

void Soldier::updateMorale(float change) {
    if (change < 0 && rand() % 100 < abs(change) * 100) {
        isDeserting = true;
    }
}